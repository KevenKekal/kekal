# -*- coding: utf-8 -*-
import LINEPY
from LINEPY import *
from akad.ttypes import *
from multiprocessing import Pool, Process
from time import sleep
import pytz, datetime, pafy, time, timeit, random, sys, ast, re, os, json, subprocess, threading, string, codecs, requests, tweepy, ctypes, urllib, wikipedia
from datetime import timedelta, date
from datetime import datetime
from bs4 import BeautifulSoup


cl = LineClient(authToken='EyQVPSM24YqBz1APtBg3.hfioqij8lMU2lxrp1ILxKW.AHZNiLEEGD6tPsQVXswN4zY1BAOP22RtHho6Cr/0L4s=')
cl.log("Auth Token : " + str(cl.authToken))
channel = LineChannel(cl)
#cl.log("Channel Access Token : " + str(channel.channelAccessToken))

ki = LineClient(authToken='EyhNlMY3qJmFxir7F5Z5.aYstC0u/OqzCpWMB4rK8vq.R3OLcVX84BIGdOP6XfXlNDZgdIKLRGXJJ8FDrbP88ps=')
ki.log("Auth Token : " + str(ki.authToken))
channel1 = LineChannel(ki)
#ki.log("Channel Access Token : " + str(channel1.channelAccessToken))

kk = LineClient(authToken='EyUbBURfOjySGPsfsIU3.25LlBV0R1DGjTbuJeuy8eW.3fFn44Uqe9ZDcUfK0zOic++Wdg4p0QKTkjJie6p4aBQ=')
kk.log("Auth Token : " + str(kk.authToken))
channel2 = LineChannel(kk)
#kk.log("Channel Access Token : " + str(channel2.channelAccessToken))

kc = LineClient(authToken='EyS9TfnEvLtrM6TtQey5.64vmqN5Raz4adk5F1jd2nq.xjs5HjJZMTq/Lcag/kWyf131VmV4z4roEp5N2+HqDsg=')
kc.log("Auth Token : " + str(kc.authToken))
channel3 = LineChannel(kc)
#kc.log("Channel Access Token : " + str(channel3.channelAccessToken))

kr = LineClient(authToken='EyXnkV9ED2c4THC1QSQ1.sL2mGwN5yZGr+je5852nWq.ApHEwlni/VHRJqjiHMLlsn5rNu6yy2hVDTLtO+xqYPY=')
kr.log("Auth Token : " + str(kr.authToken))
channel4 = LineChannel(kr)
#kr.log("Channel Access Token : " + str(channel4.channelAccessToken))

poll = LinePoll(cl)
call = cl
creator = ["u1c520e40827c2e6bb62d744fd6295793"]
owner = ["u1c520e40827c2e6bb62d744fd6295793"]
admin = ["u1c520e40827c2e6bb62d744fd6295793"]
staff = ["u1c520e40827c2e6bb62d744fd6295793"]
lineProfile = cl.getProfile()
mid = cl.getProfile().mid
Amid = ki.getProfile().mid
Bmid = kk.getProfile().mid
Cmid = kc.getProfile().mid
Dmid = kr.getProfile().mid
KAC = [cl,ki,kk,kc,kr]
Bots = [mid,Amid,Bmid,Cmid,Dmid]
Ipunk = admin + staff
#
warmode = []
protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
welcome = []

responsename = cl.getProfile().displayName
responsename1 = ki.getProfile().displayName
responsename2 = kk.getProfile().displayName
responsename3 = kc.getProfile().displayName
responsename4 = kr.getProfile().displayName

settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "autoJoinTicket":False,
    "restartPoint": {},
    "restartBot": {},
    "timeRestart": {},
    "server": {},
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
    "limit": 1,
    "creator":{},
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "contact":False,
    "invite":False,
    'autoJoin':True,
    'autoJoinTicket':False,
    'autoAdd':True,
    'autoLeave':False,
    'autoLeave1':False,
    "detectMention":True,
    "Mentionkick":False,
    "welcomeOn":False,
    "selfbot":True,
    "Addsticker":{
            "name": "",
            "status":False
            },
    "stk":{},
    "selfbot":True,
    "Images":{},
    "Img":{},
    "Addimage":{
            "name": "",
            "status":False
            },
    "Videos":{},
    "Addaudio":{
            "name": "",
            "status":False
            },
    "Addvideo":{
            "name": "",
            "status":False
            },
    "mention":"Nᴀʜ.. cakep",
    "Respontag":"Siapa namamu ?",
    "message":"ᴛᴇʀɪᴍᴀ ᴋᴀsɪʜ sᴜᴅᴀʜ ᴀᴅᴅ sᴀʏᴀ.. By.keven ",
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}

myProfile["displayName"] = lineProfile.displayName
myProfile["statusMessage"] = lineProfile.statusMessage
myProfile["pictureStatus"] = lineProfile.pictureStatus

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
#with open('owner.json', 'r') as fp:
    #owner = json.load(fp)
#with open('admin.json', 'r') as fp:
    #admin = json.load(fp)
#with open('bots.json', 'r') as fp:
   # Bots = json.load(fp)

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def mentionMembers(to, mid,name,url,iconlink):
    try:
        arrData = ""
        ginfo = cl.getGroup(to)
        textx = "╔══════════════════\n║         [ᴍᴇᴍʙᴇʀ ᴊᴏᴍʙʟᴏ]\n╠══════════════════\n╠➥ 1• "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "╠➥ {}. ".format(str(no))
            else:
                textx += "╠══════════════════\n║   Total Jones Baperan: {}   \n╚══════════════════".format(str(len(mid)))
        #cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}'),'AGENT_NAME': name,'AGENT_LINK': url,'AGENT_ICON': iconlink },0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMentionV10(to, text,name, url, iconlink):
    cl.sendMessage(to, text, {'AGENT_NAME': name,'AGENT_LINK': url,'AGENT_ICON': iconlink })

def sendMentionV9(to, text,name, url, iconlink):
    ki.sendMessage(to, text, {'AGENT_NAME': name,'AGENT_LINK': url,'AGENT_ICON': iconlink })

def sendMentionV8(to, text,name, url, iconlink):
    kk.sendMessage(to, text, {'AGENT_NAME': name,'AGENT_LINK': url,'AGENT_ICON': iconlink })

def sendMentionV7(to, text,name, url, iconlink):
    kc.sendMessage(to, text, {'AGENT_NAME': name,'AGENT_LINK': url,'AGENT_ICON': iconlink })

def sendMentionV6(to, text,name, url, iconlink):
    kr.sendMessage(to, text, {'AGENT_NAME': name,'AGENT_LINK': url,'AGENT_ICON': iconlink })

def sendMention1(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))


def sendMention2(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        ki.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        ki.sendMessage(to, "[ INFO ] Error :\n" + str(error))


def sendMention3(to, mid, firstmessage,  lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        kk.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        kk.sendMessage(to, "[ INFO ] Error :\n" + str(error))


def sendMention4(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        kc.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        kc.sendMessage(to, "[ INFO ] Error :\n" + str(error))


def sendMention5(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        kr.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        kr.sendMessage(to, "[ INFO ] Error :\n" + str(error))


def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = cl.getAllContactIds()
        gid = cl.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"➳ Jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" Wib\n➳ Group : "+str(len(gid))+"\n➳ Teman : "+str(len(teman))+"\n➳ Expired : In "+hari+"\n➳ Version : 『vezamroni』 \n➳ Tanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\n➳ Runtime : \n • "+bot
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return

        if op.type == 11:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

        if op.type == 11:
            if op.param1 in protectqr:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            cl.reissueGroupTicket(op.param1)
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            cl.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                except:
                    try:
                        if ki.getGroup(op.param1).preventedJoinByTicket == False:
                            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                ki.reissueGroupTicket(op.param1)
                                X = ki.getGroup(op.param1)
                                X.preventedJoinByTicket = True
                                ki.updateGroup(X)
                                ki.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                    except:
                        try:
                            if kk.getGroup(op.param1).preventedJoinByTicket == False:
                                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                    kk.reissueGroupTicket(op.param1)
                                    X = kk.getGroup(op.param1)
                                    X.preventedJoinByTicket = True
                                    kk.updateGroup(X)
                                    kk.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                        except:
                            try:
                                if kc.getGroup(op.param1).preventedJoinByTicket == False:
                                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                        kc.reissueGroupTicket(op.param1)
                                        X = kc.getGroup(op.param1)
                                        X.preventedJoinByTicket = True
                                        kc.updateGroup(X)
                                        kc.sendMessage(op.param1, None, contentMetadata={'mid': op.param2}, contentType=13)
                            except:
                                pass

        if op.type == 13:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Saya kurang desah jn jepit dulu\n Group " +str(ginfo.name))
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        #cl.sendMessage(op.param1,"ʜᴀʏ ᴘᴇɴɢʜᴜɴɪ" + str(ginfo.name))

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Hay semua\n " +str(ginfo.name))
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        #cl.sendMessage(op.param1,"ʜᴀʏ ᴘᴇɴɢʜᴜɴɪ " + str(ginfo.name))
            if Amid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        ki.acceptGroupInvitation(op.param1)
                        ginfo = ki.getGroup(op.param1)
                        ki.sendMessage(op.param1,"Dada\n " +str(ginfo.name))
                        ki.leaveGroup(op.param1)
                    else:
                        ki.acceptGroupInvitation(op.param1)
                        ginfo = ki.getGroup(op.param1)
                        #ki.sendMessage(op.param1,"ʜᴀʏ ᴘᴇɴɢʜᴜɴɪ " + str(ginfo.name))
            if Bmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kk.acceptGroupInvitation(op.param1)
                        ginfo = kk.getGroup(op.param1)
                        kk.sendMessage(op.param1,"Dada\n " +str(ginfo.name))
                        kk.leaveGroup(op.param1)
                    else:
                        kk.acceptGroupInvitation(op.param1)
                        ginfo = kk.getGroup(op.param1)
                        #kk.sendMessage(op.param1,"ʜᴀʏ ᴘᴇɴɢʜᴜɴɪ " + str(ginfo.name))
            if Cmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kc.acceptGroupInvitation(op.param1)
                        ginfo = kc.getGroup(op.param1)
                        kc.sendMessage(op.param1,"Dada\n " +str(ginfo.name))
                        kc.leaveGroup(op.param1)
                    else:
                        kc.acceptGroupInvitation(op.param1)
                        ginfo = kc.getGroup(op.param1)
                        #kc.sendMessage(op.param1,"Nah " + str(ginfo.name))

        if op.type == 13:
            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
            	wait["blacklist"][op.param2] = True

        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        cl.cancelGroupInvitation(op.param1,[op.param3])
                    except:
                        try:
                            ki.cancelGroupInvitation(op.param1,[op.param3])
                        except:
                            try:
                            	kk.cancelGroupInvitation(op.param1,[op.param3])
                            except:
                                try:
                            	    kc.cancelGroupInvitation(op.param1,[op.param3])
                                except:
                                    try:
                            	        kr.cancelGroupInvitation(op.param1,[op.param3])
                                    except:
                                    	pass

        if op.type == 13:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    try:
                        group = cl.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            cl.cancelGroupInvitation(op.param1,[_mid])
                    except:
                        try:
                            group = ki.getGroup(op.param1)
                            gMembMids = [contact.mid for contact in group.invitee]
                            for _mid in gMembMids:
                                ki.cancelGroupInvitation(op.param1,[_mid])
                        except:
                            try:
                                group = kk.getGroup(op.param1)
                                gMembMids = [contact.mid for contact in group.invitee]
                                for _mid in gMembMids:
                                    kk.cancelGroupInvitation(op.param1,[_mid])
                            except:
                                try:
                                    group = kc.getGroup(op.param1)
                                    gMembMids = [contact.mid for contact in group.invitee]
                                    for _mid in gMembMids:
                                        kc.cancelGroupInvitation(op.param1,[_mid])
                                except:
                                    pass

        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                cl.sendImageWithURL(op.param1, image)

        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	ki.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            if op.param3 not in wait["blacklist"]:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                if op.param3 not in wait["blacklist"]:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                pass
                return

        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendText(op.param1, wait["message"])

        if op.type == 19:
            if op.param1 in protectkick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

        if op.type == 32:
            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
            	wait["blacklist"][op.param2] = True

        if op.type == 32:
            if op.param1 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

        if op.type == 32:
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            ki.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            if op.param3 not in wait["blacklist"]:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                if op.param3 not in wait["blacklist"]:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                pass
                return

        if op.type == 19:
            if mid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        ki.inviteIntoGroup(op.param1,[op.param3])
                        cl.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            kk.inviteIntoGroup(op.param1,[op.param3])
                            cl.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                cl.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                    kr.inviteIntoGroup(op.param1,[op.param3])
                                    cl.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        G = ki.getGroup(op.param1)
                                        G.preventedJoinByTicket = False
                                        ki.updateGroup(G)
                                        Ticket = ki.reissueGroupTicket(op.param1)
                                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kr.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        G = ki.getGroup(op.param1)
                                        G.preventedJoinByTicket = True
                                        ki.updateGroup(G)
                                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                        Ticket = ki.reissueGroupTicket(op.param1)
                                    except:
                                        try:
                                            kk.kickoutFromGroup(op.param1,[op.param2])
                                            kk.inviteIntoGroup(op.param1,[op.param3])
                                            cl.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kc.kickoutFromGroup(op.param1,[op.param2])
                                                kc.inviteIntoGroup(op.param1,[op.param3])
                                                cl.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kr.kickoutFromGroup(op.param1,[op.param2])
                                                    kr.inviteIntoGroup(op.param1,[op.param3])
                                                    cl.acceptGroupInvitation(op.param1)
                                                except:
                                                    pass
                return

            if Amid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        kk.inviteIntoGroup(op.param1,[op.param3])
                        ki.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            ki.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                kr.inviteIntoGroup(op.param1,[op.param3])
                                ki.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                    cl.inviteIntoGroup(op.param1,[op.param3])
                                    ki.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        G = kk.getGroup(op.param1)
                                        G.preventedJoinByTicket = False
                                        kk.kickoutFromGroup(op.param1,[op.param2])
                                        kk.updateGroup(G)
                                        Ticket = kk.reissueGroupTicket(op.param1)
                                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kr.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        G = kk.getGroup(op.param1)
                                        G.preventedJoinByTicket = True
                                        kk.updateGroup(G)
                                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                        Ticket = ki.reissueGroupTicket(op.param1)
                                    except:
                                        try:
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                            ki.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kr.kickoutFromGroup(op.param1,[op.param2])
                                                kr.inviteIntoGroup(op.param1,[op.param3])
                                                ki.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    cl.kickoutFromGroup(op.param1,[op.param2])
                                                    cl.inviteIntoGroup(op.param1,[op.param3])
                                                    ki.acceptGroupInvitation(op.param1)
                                                except:
                                                    pass
                return

            if Bmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        kc.inviteIntoGroup(op.param1,[op.param3])
                        kk.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            kr.inviteIntoGroup(op.param1,[op.param3])
                            kk.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                cl.inviteIntoGroup(op.param1,[op.param3])
                                kk.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                    kk.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kc.inviteIntoGroup(op.param1,[mid,Amid,Bmid,Dmid])
                                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                        cl.acceptGroupInvitation(op.param1)
                                        ki.acceptGroupInvitation(op.param1)
                                        kk.acceptGroupInvitation(op.param1)
                                        kr.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kr.kickoutFromGroup(op.param1,[op.param2])
                                            kr.inviteIntoGroup(op.param1,[op.param3])
                                            kk.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                cl.kickoutFromGroup(op.param1,[op.param2])
                                                cl.inviteIntoGroup(op.param1,[op.param3])
                                                kk.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                                    kk.acceptGroupInvitation(op.param1)
                                                except:
                                                    pass
                return

            if Cmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        kr.inviteIntoGroup(op.param1,[op.param3])
                        kc.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            cl.inviteIntoGroup(op.param1,[op.param3])
                            kc.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                ki.inviteIntoGroup(op.param1,[op.param3])
                                kc.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                    kc.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        G = kr.getGroup(op.param1)
                                        G.preventedJoinByTicket = False
                                        kr.updateGroup(G)
                                        Ticket = kr.reissueGroupTicket(op.param1)
                                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kr.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        G = kc.getGroup(op.param1)
                                        G.preventedJoinByTicket = True
                                        kc.updateGroup(G)
                                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                        Ticket = kc.reissueGroupTicket(op.param1)
                                    except:
                                        try:
                                            cl.kickoutFromGroup(op.param1,[op.param2])
                                            cl.inviteIntoGroup(op.param1,[op.param3])
                                            kc.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                ki.kickoutFromGroup(op.param1,[op.param2])
                                                ki.inviteIntoGroup(op.param1,[op.param3])
                                                kc.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kk.kickoutFromGroup(op.param1,[op.param2])
                                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                                    kc.acceptGroupInvitation(op.param1)
                                                except:
                                                    pass
                return

            if Dmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        cl.inviteIntoGroup(op.param1,[op.param3])
                        kr.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                            ki.inviteIntoGroup(op.param1,[op.param3])
                            kr.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                kk.inviteIntoGroup(op.param1,[op.param3])
                                kr.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                    kr.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        G = cl.getGroup(op.param1)
                                        G.preventedJoinByTicket = False
                                        cl.updateGroup(G)
                                        Ticket = cl.reissueGroupTicket(op.param1)
                                        cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        kr.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        G = cl.getGroup(op.param1)
                                        G.preventedJoinByTicket = True
                                        kr.updateGroup(G)
                                        random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                                        Ticket = kr.reissueGroupTicket(op.param1)
                                    except:
                                        try:
                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                            ki.inviteIntoGroup(op.param1,[op.param3])
                                            kr.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kk.kickoutFromGroup(op.param1,[op.param2])
                                                kk.inviteIntoGroup(op.param1,[op.param3])
                                                kr.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                                    kr.acceptGroupInvitation(op.param1)
                                                except:
                                                    pass
                return

            if op.type == 19:
                if op.param3 in admin:
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            ki.kickoutFromGroup(op.param1,[op.param2])
                            ki.findAndAddContactsByMid(op.param1,admin)
                            ki.inviteIntoGroup(op.param1,admin)
                        except:
                            try:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                                kk.findAndAddContactsByMid(op.param1,admin)
                                kk.inviteIntoGroup(op.param1,admin)
                            except:
                                try:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.findAndAddContactsByMid(op.param1,admin)
                                    kc.inviteIntoGroup(op.param1,admin)
                                except:
                                    pass

                return

            if op.type == 19:
                if op.param3 in staff:
                    try:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        cl.findAndAddContactsByMid(op.param3)
                        cl.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            ki.kickoutFromGroup(op.param1,[op.param2])
                            ki.findAndAddContactsByMid(op.param1,admin)
                            ki.inviteIntoGroup(op.param1,admin)
                        except:
                            try:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                                kk.findAndAddContactsByMid(op.param1,admin)
                                kk.inviteIntoGroup(op.param1,admin)
                            except:
                                try:
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.findAndAddContactsByMid(op.param1,admin)
                                    kc.inviteIntoGroup(op.param1,admin)
                                except:
                                    pass
                return

        if op.type == 55:
            try:
                if op.param1 in Setmain["RAreadPoint"]:
                   if op.param2 in Setmain["RAreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["RAreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          random.choice(KAC).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              random.choice(KAC).kickoutFromGroup(msg.to, [msg._from])
                          except:
                              random.choice(KAC).kickoutFromGroup(msg.to, [msg._from])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"🐥 Nama : " + msg.contentMetadata["displayName"] + "\n🐥 MID : " + msg.contentMetadata["mid"] + "\n🐥 Status Msg : " + contact.statusMessage + "\n🐥 Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"🐥 Nama : " + msg.contentMetadata["displayName"] + "\n🐥 MID : " + msg.contentMetadata["mid"] + "\n🐥 Status Msg : " + contact.statusMessage + "\n🐥 Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                if msg._from in admin:
                  if wait["invite"] == True:
                    msg.contentType = 0
                    contact = cl.getContact(msg.contentMetadata["mid"])
                    invite = msg.contentMetadata["mid"]
                    groups = cl.getGroup(msg.to)
                    pending = groups.invitee
                    targets = []
                    for s in groups.members:
                        if invite in wait["blacklist"]:
                            cl.sendMessage(msg.to, "ᴅɪᴀ ʙᴇʀᴀᴅᴀ dɪ ᴅᴀғᴛᴀʀ ʜɪᴛᴀᴍ\nᴜɴʙᴀɴ ᴅᴜʟᴜ ᴊᴇᴘɪᴛ ʟᴀɢɪ ...")
                            break
                        else:
                            targets.append(invite)
                    if targets == []:
                        pass
                    else:
                         for target in targets:
                             try:
                                  cl.findAndAddContactsByMid(target)
                                  cl.inviteIntoGroup(msg.to,[target])
                                  ipunk = cl.getContact(target)
                                  zx = ""
                                  zxc = ""
                                  zx2 = []
                                  xpesan =  "ʙᴇʀʜᴀsɪʟ ᴊᴇᴘɪᴛ.. \nNama "
                                  ret_ = "Ketik invite off jika sudah masuk"
                                  ry = str(veza.displayName)
                                  pesan = ''
                                  pesan2 = pesan+"@x\n"
                                  xlen = str(len(zxc)+len(xpesan))
                                  xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                  zx = {'S':xlen, 'E':xlen2, 'M':veza.mid}
                                  zx2.append(zx)
                                  zxc += pesan2
                                  text = xpesan + zxc + ret_ + ""
                                  cl.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                  wait["invite"] = False
                                  break
                             except:
                                  cl.sendText(msg.to,"ᴋᴀᴍᴜ ᴍᴀsɪʜ ʟɪᴍɪᴛ.")
                                  wait["invite"] = False
                                  break
#ADD Bots
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        cl.sendMessage(msg.to,"Succes")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        cl.sendMessage(msg.to,"Succes")
                 if wait["delbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Succes")
                    else:
                        wait["delbots"] = True
                        ki.sendMessage(msg.to,"Contact not listbot")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        cl.sendMessage(msg.to,"Contact succes add staff")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        cl.sendMessage(msg.to,"Succes")
                 if wait["delstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Succes")
                        wait["delstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        ki.sendMessage(msg.to,"Contact not staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        cl.sendMessage(msg.to,"Contact Succes add admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        cl.sendMessage(msg.to,"Succes")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Succes")
                    else:
                        wait["deladmin"] = True
                        ki.sendMessage(msg.to,"Contact not admin")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"Contact Succes add blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        cl.sendMessage(msg.to,"Succes")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes")
                    else:
                        wait["dblacklist"] = True
                        cl.sendMessage(msg.to,"Succes")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        cl.sendMessage(msg.to,"Contact Succes add Talkban list")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        cl.sendMessage(msg.to,"Succes")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes")
                    else:
                        wait["Talkdblacklist"] = True
                        cl.sendMessage(msg.to,"Contact not Tlakban list")
#UPDATE FOTO
               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     cl.sendMessage(msg.to, "Succes")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["TJfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["TJfoto"][mid]
                            cl.updateProfilePicture(path)
                            cl.sendMessage(msg.to,"Succes")

               if msg.contentType == 1:
                 if msg._from in admin:
                        if Amid in Setmain["TJfoto"]:
                            path = ki.downloadObjectMsg(msg_id)
                            del Setmain["TJfoto"][Amid]
                            ki.updateProfilePicture(path)
                            ki.sendMessage(msg.to,"Succes")
                        elif Bmid in Setmain["TJfoto"]:
                            path = kk.downloadObjectMsg(msg_id)
                            del Setmain["TJfoto"][Bmid]
                            kk.updateProfilePicture(path)
                            kk.sendMessage(msg.to,"Succes")
                        elif Cmid in Setmain["TJfoto"]:
                            path = kc.downloadObjectMsg(msg_id)
                            del Setmain["TJfoto"][Cmid]
                            kc.updateProfilePicture(path)
                            kc.sendMessage(msg.to,"Succes")
                        elif Dmid in Setmain["TJfoto"]:
                            path = kr.downloadObjectMsg(msg_id)
                            del Setmain["TJfoto"][Dmid]
                            kr.updateProfilePicture(path)
                            kr.sendMessage(msg.to,"Succes")

               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = ki.downloadObjectMsg(msg_id)
                     path2 = kk.downloadObjectMsg(msg_id)
                     path3 = kc.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     ki.updateProfilePicture(path1)
                     ki.sendMessage(msg.to, "Succes change pic")
                     kk.updateProfilePicture(path2)
                     kk.sendMessage(msg.to, "Succes change pic")
                     kc.updateProfilePicture(path3)
                     kc.sendMessage(msg.to, "Succes change pic")
                     kr.updateProfilePicture(path3)
                     kr.sendMessage(msg.to, "Succes change pic")


               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)

                        if cmd == "bl on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                cl.sendText(msg.to, "ʙᴏᴛ ᴀʟʟʀᴇᴀᴅʏ ᴏɴ")

                        elif cmd == "bl off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                cl.sendText(msg.to, "ʙᴏᴛ ᴀʟʟʀᴇᴀᴅʏ ᴏғғ")

                        if cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                key = str(Setmain["keyCommand"])
                                ret_ = "☠ Keven⁷⁴ ☠"
                                ret_ += "\n"
                                ret_ += "\n🕸"+key+"help"
                                ret_ += "\n🕸"+key+"klpro on | Mcpro off"
                                ret_ += "\n🕸"+key+"Jointicket on|off"
                                ret_ += "\n🕸"+key+"sp"
                                ret_ += "\n🕸"+key+"Me"
                                ret_ += "\n🕸"+key+"Setting"
                                ret_ += "\n🕸"+key+"Runtime"
                                ret_ += "\n🕸"+key+"About"
                                ret_ += "\n🕸"+key+"Listpro"
                                ret_ += "\n🕸"+key+"Absen"
                                ret_ += "\n🕸"+key+"Ingat"                             
                                ret_ += "\n🕸"+key+"Reject"
                                ret_ += "\n🕸"+key+"Block on/off"
                                ret_ += "\n🕸"+key+"Go @"
                                ret_ += "\n🕸"+key+"reset"
                                ret_ += "\n🕸"+key+"Pqr on|off"
                                ret_ += "\n🕸"+key+"Pinvite on|off"
                                ret_ += "\n🕸"+key+"Pkick on|off"
                                ret_ += "\n🕸"+key+"Pjoin on|off"                                                                                                             
                                ma = cl.getProfile()                                
                                name = "[MENU]"
                                url = 'http://line.me/ti/p/~memegangmu'
                                iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(ma.pictureStatus))
                                sendMentionV10(msg.to, str(ret_), str(name), str(url), str(iconlink))

                        elif cmd == "setting":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "┏━━━━━━━━━━━━━━━\n┣━━━[Status Bots]\n"
                                if msg.to in protectinvite:
                                    md+="┣ UNSEND        •➤ On\n"
                                else:
                                    md+="┣ UNSEND        •➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣AUTOCHAT   •➤ On\n"
                                else:
                                    md+="┣AUTOCHAT   •➤ Off\n"
                                if msg.to in protectqr:
                                    md+="┣InstaPoint •➤ On\n"
                                else:
                                    md+="┣InstaPoint •➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣WELCOME     •➤ On\n"
                                else:
                                    md+="┣WELCOME     •➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣STICKER        •➤ On\n"
                                else:
                                    md+="┣STICKER        •➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣RESPONTAG •➤ On\n"
                                else:
                                    md+="┣RESPONTAG •➤ Off\n"
                                if msg.to in protectqr:
                                    md+="┣AUTOJOIN    •➤ On\n"
                                else:
                                    md+="┣AUTOJOIN    •➤ Off\n"
                                if msg.to in protectqr:
                                    md+="┣JOINTICKET  •➤ On\n"
                                else:
                                    md+="┣JOINTICKET •➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣AUTO ADD    •➤ On\n"
                                else:
                                    md+="┣AUTO ADD    •➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣PRO QR         •➤ On\n"
                                else:
                                    md+="┣PRO QR         •➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣PRO CANCEL•➤ On\n"
                                else:
                                    md+="┣PRO CANCEL•➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣PRO JS          •➤ On\n"
                                else:
                                    md+="┣PRO JS          •➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣PRO MEMB   •➤ On\n"
                                else:
                                    md+="┣PRO MEMB  •➤ Off\n"
                                if msg.to in protectjoin:
                                    md+="┣PRO JOIN     •➤ On\n"
                                else:
                                    md+="┣PRO JOIN      •➤ Off\n"
                                if msg.to in protectkick:
                                    md+="┣PRO KICK     •➤ On\n"
                                else:
                                    md+="┣PRO KICK      •➤ Off\n"
                                if msg.to in protectinvite:
                                    md+="┣PRO INVITE   •➤ On\n"
                                else:
                                    md+="┣PRO INVITE   •➤ Off\n┣━━━━━━━━━━━━━━"                                
                                    md+="☠ Keven⁷⁴ ☠"
                                    md+="\n┃⌛ Jam: "+ datetime.strftime(timeNow,'%H:%M:%S')
                                    md+="\n┃📆 Tanggal: "+ datetime.strftime(timeNow,'%Y-%m-%d')
                                    md+="\n┣➤   Ҝ乇Ҝ卂ㄥ™ \n┗━━━━━━━━━━━━━━"
                                ma = cl.getProfile()
                                name = "keven"
                                url = "http://line.me/ti/p/udqCTt7kIc"
                                cl.sendText(msg.to, md)
                                
                        elif cmd == "creator" or text.lower() == 'creator':
                            if msg._from in admin:
                                cl.sendText(msg.to,"Creator bot")
                                ma = ""
                                for i in creator:
                                    ma = cl.getContact(i)
                                    sendMention1(msg.to, sender, "「 ᴄʀᴇᴀᴛᴏʀ 」\n","")
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "about" or cmd == "informasi":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendMention(msg.to, sender, "「  ᴜsᴇʀ  」\n")
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': mid}, contentType=13)

                      #  elif cmd == ".me" or text.lower() == '/me':
                      #    if wait["selfbot"] == True:
                        #    if msg._from in admin:
                        #       sendMention1(msg.to, sender, " ◾ɴᴀᴍᴀ sᴀʏᴀ\n「", "」")
                        #       msg.contentType = 13
                     #          msg.contentMetadata = {'mid': mid}
                         #      cl.sendMessage1(msg)

                        elif cmd == ".me" or text.lower() == '/me':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendMention1(msg.to, sender, " ◾мү вσss\n「", "」")
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': mid}
                               cl.sendMessage1(msg)
                               
                        elif  cmd == "me":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               contact = cl.getProfile()
                               mids = [contact.mid]
                               name = "{}".format(str(contact.displayName))
                               url = 'https://line.me/ti/p/~memegangmu'
                               iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(contact.pictureStatus))
                               text = "「  мү вσss」"
                               sendMentionV10(msg.to, str(text), str(name), str(url), str(iconlink))
                               cl.sendMessage(msg.to, "{}".format(contact.displayName),contentMetadata = {'previewUrl': 'http://dl.profile.line-cdn.net/'+cl.getContact(mid).pictureStatus, 'i-installUrl': 'https://line.me/ti/p/{}'.format(cl.getUserTicket().id), 'type': 'mt', 'subText': "Vezamroni Evendy", 'a-installUrl': 'https://line.me/ti/p/{}'.format(cl.getUserTicket().id), 'a-installUrl': 'https://line.me/ti/p/{}'.format(cl.getUserTicket().id), 'a-packageName': 'com.spotify.music', 'countryCode': 'ID', 'a-linkUri': 'https://line.me/ti/p/{}'.format(cl.getUserTicket().id), 'i-linkUri': 'https://line.me/ti/p/{}'.format(cl.getUserTicket().id), 'id': 'mt000000000a6b79f9', 'text': '{}'.format(contact.displayName), 'linkUri': 'https://line.me/ti/p/{}'.format(cl.getUserTicket().id)}, contentType=19)

                        elif text.lower() == ".mid":
                               cl.sendMessage(msg._from)

                        elif "/ti/g/" in msg.text.lower():
                           if msg._from in admin:
                             if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                    if l not in n_links:
                                       n_links.append(l)
                                 for ticket_id in n_links:
                                    group = cl.findGroupByTicket(ticket_id)
                                    cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    cl.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                    group1 = ki.findGroupByTicket(ticket_id)
                                    ki.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                    ki.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                    group2 = kk.findGroupByTicket(ticket_id)
                                    kk.acceptGroupInvitationByTicket(group2.id,ticket_id)
                                    kk.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                    group3 = kc.findGroupByTicket(ticket_id)
                                    kc.acceptGroupInvitationByTicket(group3.id,ticket_id)
                                    kc.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                    group4 = kr.findGroupByTicket(ticket_id)
                                    kr.acceptGroupInvitationByTicket(group4.id,ticket_id)
                                    kr.sendMessage(msg.to, "Masuk : %s" % str(group.name))

                        elif text.lower() == "my removechat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                               except:
                                   pass

                        elif text.lower() == "jchat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                                   ki.removeAllMessages(op.param2)
                                   kk.removeAllMessages(op.param2)
                                   kc.removeAllMessages(op.param2)
                                   kr.removeAllMessages(op.param2)
                                   contact = cl.getProfile()
                                   mids = [contact.mid]
                                   name = "prilly"
                                   url = 'https://line.me/ti/p/~memegangmu'
                                   iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(contact.pictureStatus))
                                   text = "ᴄʟᴇᴀʀ ᴄʜᴀᴛ ᴅᴏɴᴇ"
                                   sendMentionV10(msg.to, str(text), str(name), str(url), str(iconlink))
                                   #sendMention1(msg.to, sender, "ʀᴜᴀɴɢ ᴄʜᴀᴛ mu「", "」\nSᴜᴅᴀʜ Dɪ Bersihkan..")
                               except:
                                   pass

                        elif text.lower() == "bl":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.sendText(msg.to,"ʙᴏᴛ ᴍᴀsɪʜ ʜɪᴅᴜᴘ..  \nʙᴇʟᴜᴍ ʀᴇᴠᴏᴋᴇ.. ")
                               except:
                                   pass

                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Mykey」\nSetkey bot mu「 " + str(Setmain["keyCommand"]) + " 」")

                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   cl.sendMessage(msg.to, "「Setkey」\nSetkey diganti jadi「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               cl.sendMessage(msg.to, "「Setkey」\nSetkey mu kembali ke awal")

                        elif cmd == "reset":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "Loading Restarting...")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               cl.sendMessage(msg.to, "Silahkan gunakan seperti semula...")

                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "Aktif " +waktu(eltime)
                               contact = cl.getProfile()
                               mids = [contact.mid]
                               name = "{}".format(str(contact.displayName))
                               url = 'https://line.me/ti/p/~memegangmu'
                               iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(contact.pictureStatus))
                               sendMentionV10(msg.to, str(bot), str(name), str(url), str(iconlink))
                               #cl.sendMessage(msg.to,bot)

                        elif cmd == "Gfoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                cl.sendText(msg.to,"•➣ Kirim fotonya..")

                        elif cmd == "Bfoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                cl.sendText(msg.to,"•➣ Kirim fotonya..")

                        elif cmd == "bl1foto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["TJfoto"][mid] = True
                                cl.sendText(msg.to,"•➣ Send pict...")

                        elif cmd == "bl2foto":
                            if msg._from in admin:
                                Setmain["TJfoto"][Amid] = True
                                ki.sendText(msg.to,"•➣ Send pict...")

                        elif cmd == "bl3foto":
                            if msg._from in admin:
                                Setmain["TJfoto"][Bmid] = True
                                kk.sendText(msg.to,"•➣ Send pict...")

                        elif cmd == "bl4foto":
                            if msg._from in admin:
                                Setmain["TJfoto"][Cmid] = True
                                kc.sendText(msg.to,"•➣ Send pict...")

                        elif cmd == "bl5foto":
                            if msg._from in admin:
                                Setmain["TJfoto"][Dmid] = True
                                kr.sendText(msg.to,"•➣ Send pict...")

                        elif cmd.startswith("bl1nama: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"Succes " + string + "")

                        elif cmd.startswith("bl2nama: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ki.getProfile()
                                profile.displayName = string
                                ki.updateProfile(profile)
                                ki.sendMessage(msg.to,"Succes " + string + "")

                        elif cmd.startswith("bl3nama: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kk.getProfile()
                                profile.displayName = string
                                kk.updateProfile(profile)
                                kk.sendMessage(msg.to,"Succes " + string + "")

                        elif cmd.startswith("bl4nama: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kc.getProfile()
                                profile.displayName = string
                                kc.updateProfile(profile)
                                kc.sendMessage(msg.to,"Succes " + string + "")

                        elif cmd.startswith("bl5nama: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kr.getProfile()
                                profile.displayName = string
                                kr.updateProfile(profile)
                                kr.sendMessage(msg.to,"Succes " + string + "")

#===========BOT UPDATE============#

                        elif cmd == "hay" or text.lower() == 'anu':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               group = cl.getGroup(msg.to)
                               za = cl.getProfile()
                               name = "{}".format(str(group.name))
                               url = 'https://line.me/R/ti/g/{}'.format(str(cl.reissueGroupTicket(group.id)))
                               iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(group.pictureStatus))
                               nama = [contact.mid for contact in group.members]
                               nm1, nm2, nm3, nm4, jml = [], [], [], [], len(nama)                                                      
                               if jml <= 20:
                                   mentionMembers(msg.to, nama,name,url,iconlink)
                               if jml > 20 and jml < 40:
                                   for i in range (0, 20):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1,name,url,iconlink)
                                   for j in range (20, len(nama)):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2,name,url,iconlink)
                               if jml > 40 and jml < 60:
                                   for i in range (0, 20):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1,name,url,iconlink)
                                   for j in range (20, 40):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2,name,url,iconlink)
                                   for k in range (40, len(nama)):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3,name,url,iconlink)
                               if jml > 60 and jml < 80:
                                   for i in range (0, 20):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1,name,url,iconlink)
                                   for j in range (20,40 ):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2,name,url,iconlink)
                                   for k in range (40, 60):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3,name,url,iconlink)
                                   for l in range (60, len(nama)):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4,name,url,iconlink)
                               if jml > 80 and jml < 100:
                                   for i in range (0, 20):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1,name,url,iconlink)
                                   for j in range (20, 40):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2,name,url,iconlink)
                                   for k in range (40, 60):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3,name,url,iconlink)
                                   for l in range (60, 80):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4,name,url,iconlink)
                                   for m in range (80, len(nama)):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5,name,url,iconlink)
                               if jml > 100 and jml < 120:
                                   for i in range (0, 20):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1,name,url,iconlink)
                                   for j in range (20, 40):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2,name,url,iconlink)
                                   for k in range (40, 60):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3,name,url,iconlink)
                                   for l in range (60, 80):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4,name,url,iconlink)
                                   for m in range (80, 100):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5,name,url,iconlink)
                                   for n in range (100, len(nama)):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6,name,url,iconlink)
                               if jml > 120 and jml < 140:
                                   for i in range (0, 20):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1,name,url,iconlink)
                                   for j in range (20, 40):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2,name,url,iconlink)
                                   for k in range (40, 60):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3,name,url,iconlink)
                                   for l in range (60, 80):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4,name,url,iconlink)
                                   for m in range (80, 100):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5,name,url,iconlink)
                                   for n in range (100, 120):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6,name,url,iconlink)
                                   for o in range (120, len(nama)):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7,name,url,iconlink)
                               if jml > 140 and jml < 160:
                                   for i in range (0, 20):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1,name,url,iconlink)
                                   for j in range (20, 40):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2,name,url,iconlink)
                                   for k in range (40, 60):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3,name,url,iconlink)
                                   for l in range (60, 80):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4,name,url,iconlink)
                                   for m in range (80, 100):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5,name,url,iconlink)
                                   for n in range (100, 120):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6,name,url,iconlink)
                                   for o in range (120, 140):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7,name,url,iconlink)
                                   for p in range (140, len(nama)):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8,name,url,iconlink)
                               if jml > 160 and jml < 180:
                                   for i in range (0, 20):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1,name,url,iconlink)
                                   for j in range (20, 40):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2,name,url,iconlink)
                                   for k in range (40, 60):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3,name,url,iconlink)
                                   for l in range (60, 80):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4,name,url,iconlink)
                                   for m in range (80, 100):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5,name,url,iconlink)
                                   for n in range (100, 120):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6,name,url,iconlink)
                                
  #[==Finish===]

                        elif cmd == "bot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"•『LIST ALLBOT』•\n\n"+ma+"\nTotal : 『%s』 Bot" %(str(len(Bots))))

                        elif cmd == "admin":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"•『LIST ADMIN BOT』•\n\n✮ ᴏᴡɴᴇʀ:\n"+ma+"\n⌬ ᴀᴅᴍɪɴ:\n"+mb+"\n✜ sᴛᴀғғ:\n"+mc+"\nTotal :「%s」\n Admin Bot" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "listpro":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                a = 0
                                b = 0
                                c = 0
                                d = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectkick
                                for group in gid:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectjoin
                                for group in gid:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getGroup(group).name + "\n"
                                cl.sendMessage(msg.to,"•「LIST PROTECT GRUP」•\n\n➳ Pʀᴏᴛᴇᴄᴛ ᴜʀʟ:\n"+ma+"\n➳ Pʀᴏᴛᴇᴄᴛ ᴋɪᴄᴋ:\n"+mb+"\n➳ Pʀᴏᴛᴇᴄᴛ ᴊᴏɪɴ:\n"+md+"\n➳ Pʀᴏᴛᴇᴄᴛ ᴄᴀɴᴄᴇʟ:\n"+mc+"\n「%s」ʟɪsᴛ ᴘʀᴏᴛᴇᴄᴛ ɢʀᴏᴜᴘ" %(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel))))

                        elif cmd == "reject":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      cl.rejectGroupInvitation(gid)
                                  cl.sendMessage(to, "Berhasil tolak sebanyak {} undangan grup".format(str(len(ginvited))))
                              else:
                                  cl.sendMessage(to, "Tidak ada undangan yang tertunda")

                        elif cmd == "absen" or text.lower() == '/rjeneng':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                cl.sendMessage(msg.to,responsename)
                                ki.sendMessage(msg.to,responsename1)
                                kk.sendMessage(msg.to,responsename2)
                                kc.sendMessage(msg.to,responsename3)
                                kr.sendMessage(msg.to,responsename4)

                        elif cmd == "respon" or text.lower() == 'ingat':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                sendMention1(msg.to, sender, "1「", "」")
                                sendMention2(msg.to, sender, "2「", "」")
                                sendMention3(msg.to, sender, "3「", "」")
                                sendMention4(msg.to, sender, "4「", "」")
                                sendMention5(msg.to, sender, "5「", "」")

                        elif cmd == "ivt":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = [Amid,Bmid,Cmid]
                                    cl.inviteIntoGroup(msg.to, anggota)
                                    ki.acceptGroupInvitation(msg.to)
                                    kk.acceptGroupInvitation(msg.to)
                                    kc.acceptGroupInvitation(msg.to)
                                    kr.acceptGroupInvitation(msg.to)
                                except:
                                    pass

                        elif cmd == "suk":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                ginfo = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kr.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = kr.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                kr.updateGroup(G)
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                name = "{}".format(str(contact.displayName))
                                url = 'https://line.me/ti/p/~memegangmu'
                                iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(contact.pictureStatus))
                                text = "Halo semua..assalamualaikum..  "
                                sendMentionV6(msg.to, str(text), str(name), str(url), str(iconlink))
                                #sendMention5(msg.to, sender, "ʜᴀʏ「", "」Sayang")

                        elif cmd == "minggat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                wait["autoJoin"] = True
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                name = "{}".format(str(contact.displayName))
                                url = 'https://line.me/ti/p/~memegangmu'
                                iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(contact.pictureStatus))
                                text = "god bye"
                                sendMentionV9(msg.to, str(text), str(name), str(url), str(iconlink))
                                #sendMention2(msg.to, sender, "sᴀʏᴀɴɢ ᴋᴜ「", "」\nsᴀᴍᴘᴀɪ ɴᴀɴᴛɪ..")                                
                                ki.leaveGroup(msg.to)
                                kk.leaveGroup(msg.to)
                                kc.leaveGroup(msg.to)
                                kr.leaveGroup(msg.to)

                        elif cmd == "bubar":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                sendMention1(msg.to, sender, "heleh kintil「", "」\nAku di usir juga.."+str(G.name))
                                cl.leaveGroup(msg.to)

                        elif cmd == "spbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = cl.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = cl.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = cl.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                                cl.sendMessage(msg.to, "✬ Respon Speed ✬\n\n - ✬ Speed Profile\n   %.10f\n - ✬ Speed Contact\n   %.10f\n - ✬ Speed Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))


                        elif cmd == "sp" or cmd == "cs":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendMention1(msg.to, sender, "◾Sabar ini ujian...\n「", "」")
                               start = time.time()
                               time.sleep(1.800) # speed 1.800
                               elapsed_time = time.time() - start
                               cl.sendText(msg.to, "「%s」" % (elapsed_time))

                        elif cmd == "mc sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                start = time.time()
                                #cl.sendText("u253f80da33807dacb73b96b18fc9d2fd", '.')
                                elapsed_time = (time.time() - start)
                                cl.sendText(msg.to, "「%s」Detik.." % (elapsed_time))

                                start2 = time.time()
                             #   cl.sendText("u253f80da33807dacb73b96b18fc9d2fd", '.')
                                elapsed_time = (time.time() - start2)
                                ki.sendText(msg.to, "「%s」Detik.." % (elapsed_time))

                                start3 = time.time()
                             #   cl.sendText("u253f80da33807dacb73b96b18fc9d2fd", '.')
                                elapsed_time = (time.time() - start3)
                                kk.sendText(msg.to, "「%s」Detik.." % (elapsed_time))

                                start4 = time.time()
                              #  cl.sendMessage("u253f80da33807dacb73b96b18fc9d2fd", '.')
                                elapsed_time = (time.time() - start4)
                                kc.sendText(msg.to, "「%s」Detik.." % (elapsed_time))

                                start5 = time.time()
                            #    cl.sendMessage("u253f80da33807dacb73b96b18fc9d2fd", '.')
                                elapsed_time = (time.time() - start5)
                                kr.sendText(msg.to, "「%s」Detik.." % (elapsed_time))

                        elif 'proqr: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('proqr: ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "Succes"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect url off\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect url off\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect url on"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Prokick: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Prokick: ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "Protect kick on"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect kick off\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect kick Off\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect kick on"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Projoin: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Projoin: ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "Protect join on"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect join on\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect join off\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect join off"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Procancel: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Procancel: ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "Protect cancel on"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect cancel on\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect cancel off\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect cancel off"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                      #  elif cmd.startswith('inta '):
                         #  if msg._from in admin:
                            #  spl = cmd.replace('inta ','')
                            #  if spl == 'on':
                                #  if msg.to in warmode:
                                 #      msgs = "Sukses"
                              #    else:
                                 #      warmode[msg.to] = True
                              #         gegeProtect()
                                    #   ginfo = cl.getGroup(msg.to)
                                    #   msgs = "Sukses"
                               #   cl.sendMessage(msg.to, msgs)
                           #   elif spl == 'off':
                                  #  if msg.to in warmode:
                                       #  del warmode[msg.to]
                                      #   gegeProtect()
                                     #    ginfo = cl.getGroup(msg.to)
                                      #   msgs = "Sukses"
                                 #   else:
                                  #       msgs = "Sukses"
                                #    cl.sendMessage(msg.to, msgs)
                                    
                        elif 'klpro ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('klpro ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectjoin:
                                      msgs = ""
                                  else:
                                      protectjoin.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Allprotect on Succes\n➳ : " +str(ginfo.name)
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Succes Allprotect on\n➳ : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Allprotect off Succes\n➳ : " +str(ginfo.name)
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Allprotect off Succes\n➳ : " +str(ginfo.name)
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

#===========KICKOUT============#
                        elif ("kl kick " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           cl.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Go " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           random.choice(KAC).kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("kl1 go" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           ki.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("kl2 go" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           kk.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("kl3 go" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           kc.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

#===========ADMIN ADD============#
                        elif ("Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in creator:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           cl.sendMessage(msg.to,"Succes add admin")
                                       except:
                                           pass

                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           cl.sendMessage(msg.to,"Succes add staff")
                                       except:
                                           pass

                        elif ("Botadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Bots.append(target)
                                           cl.sendMessage(msg.to,"Succes add bot")
                                       except:
                                           pass

                        elif ("Admindel " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in ipunk:
                                       try:
                                           admin.remove(target)
                                           cl.sendMessage(msg.to,"Succes delete admin")
                                       except:
                                           pass

                        elif ("Staffdel " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in ipunk:
                                       try:
                                           staff.remove(target)
                                           cl.sendMessage(msg.to,"Succes delete admin")
                                       except:
                                           pass

                        elif ("Botdel " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in ipunk:
                                       try:
                                           Bots.remove(target)
                                           cl.sendMessage(msg.to,"Succes delete admin")
                                       except:
                                           pass

                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif cmd == "admin:dell" or text.lower() == 'admin:dell':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            if msg._from in admin:
                                wait["addstaff"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif cmd == "staff:dell" or text.lower() == 'staff:dell':
                            if msg._from in admin:
                                wait["dellstaff"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if msg._from in admin:
                                wait["addbots"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif cmd == "bot:dell" or text.lower() == 'bot:dell':
                            if msg._from in admin:
                                wait["dellbots"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif cmd == "clear" or text.lower() == 'segarkan':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                name = "prilly"
                                url = 'https://line.me/ti/p/~memegangmu'
                                iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(contact.pictureStatus))
                                text = "sᴜᴅᴀʜ ᴅɪ ʀᴇғʀᴇsʜ"
                                sendMentionV10(msg.to, str(text), str(name), str(url), str(iconlink))
                                #sendMention1(msg.to, sender, "", " \nsᴜᴅᴀʜ ᴅɪ ʀᴇғʀᴇsʜ ᴢᴀ...")

                        elif cmd == "contact admin" or text.lower() == 'contact admin':
                            if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact staff" or text.lower() == 'contact staff':
                            if msg._from in admin:
                                ma = ""
                                for i in staff:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact bot" or text.lower() == 'contact bot':
                            if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == "invite on" or text.lower() == 'invite on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = True
                                sendMention1(msg.to, sender, "", "\nSilahkan kirim kontaknya za.. ")

                        elif cmd == "invite off" or text.lower() == 'invite off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["invite"] = False
                                sendMention1(msg.to, sender, "", " \nInvite via contact dinonaktifkan")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                cl.sendText(msg.to,"Contact allready on")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                cl.sendText(msg.to,"Contact allready off")

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                cl.sendText(msg.to,"Auto allready on")

                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                cl.sendText(msg.to,"Auto respon allready off")

                        elif cmd == "join on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                name = "prilly"
                                url = 'https://line.me/ti/p/~memegangmu'
                                iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(contact.pictureStatus))
                                text = "ᴀᴜᴛᴏ ᴊᴏɪɴ ᴏɴ"
                                sendMentionV10(msg.to, str(text), str(name), str(url), str(iconlink))
                                #cl.sendText(msg.to,"Autojoin allredy on")

                        elif cmd == "ajoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                contact = cl.getProfile()
                                mids = [contact.mid]
                                name = "prilly"
                                url = 'https://line.me/ti/p/~memegangmu'
                                iconlink = 'http://dl.profile.line-cdn.net/{}'.format(str(contact.pictureStatus))
                                text = "ᴀᴜᴛᴏ ᴊᴏɪɴ ᴏff"
                                sendMentionV10(msg.to, str(text), str(name), str(url), str(iconlink)) 
                                #cl.sendText(msg.to,"Autojoin allready off")

                        elif cmd == "aleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                cl.sendText(msg.to,"Autoleave allready on")

                        elif cmd == "aleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                cl.sendText(msg.to,"Autoleave allready off")

                        elif cmd == "aadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                cl.sendText(msg.to,"Auto add allready on")

                        elif cmd == "aadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                cl.sendText(msg.to,"Auto add allready off")

                        elif cmd == "ticket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = True
                                sendMention1(msg.to, sender, "「", "」\nKirim link grupnya za,\nBiar aku masuk..")

                        elif cmd == "ticket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["autoJoinTicket"] = False
                                sendMention1(msg.to, sender, "「", "」\nJointicket off")

#===========COMMAND BLACKLIST============#
                        elif ("Talkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           cl.sendMessage(msg.to,"Succses")
                                       except:
                                           pass

                        elif ("Untalkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           cl.sendMessage(msg.to,"Succes")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif ("Kick " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           #cl.sendMessage(msg.to,"Succes")
                                       except:
                                           pass

                        elif ("Kik " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           #cl.sendMessage(msg.to,"Succes")
                                       except:
                                           pass

                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           cl.sendMessage(msg.to,"Succes")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                cl.sendText(msg.to,"Send Contact...")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                cl.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"  『ʙʟᴀᴄᴋʟɪsᴛ』\n\n"+ma+"\n「%s」Blacklist User " %(str(len(wait["blacklist"]))))

                        elif cmd == "bl banlist" or text.lower() == 'Punk banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                cl.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"•☠『ʙʟᴀᴄᴋʟɪsᴛ』☠•\n\n"+ma+"\n➳「%s」Blacklist User ☑" %(str(len(wait["blacklist"]))))

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                cl.sendMessage(msg.to,"No Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"•☠『Talkban User』☠•\n\n"+ma+"\n➳「%s」Talkban User ☑" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == "blc" or text.lower() == 'punk blc':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    cl.sendMessage(msg.to,"ᴛɪᴅᴀᴋ ᴀᴅᴀ ʙʟᴀᴄᴋʟɪsᴛ")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "clearban" or text.lower() == 'punk clear':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              #ragets = cl.getContacts(wait["blacklist"])
                              #mc = "(%i)Pelaku" % len(ragets)
                              sendMention1(msg.to, sender, "", " \nᴄʟᴇᴀʀ: {} ʙʟᴀᴄᴋʟɪsᴛ".format(str(len(wait["blacklist"]))))
                              wait["blacklist"] = {}
#===========COMMAND SET============#
                        elif cmd == "bl clearban" or text.lower() == 'Punk clearban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              #wait["blacklist"] = {}
                              #ragets = cl.getContacts(wait["blacklist"])
                              mc = "(%i)Pelaku" % len(ragets)
                              sendMention1(msg.to, sender, "", " \nᴄʟᴇᴀʀ ʙʟᴀᴄᴋʟɪsᴛ" +mc)
#===========COMMAND SET============#
                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Sider Msg」\nSider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")


    except Exception as error:
        print (error)


while True:
    try:
        ops = poll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
               # bot(op)
                # Don't remove this line, if you wan't get error soon!
                poll.setRevision(op.revision)
                thread1 = threading.Thread(target=bot, args=(op,))#self.OpInterrupt[op.type], args=(op,)
                #thread1.daemon = True
                thread1.start()
                thread1.join()
    except Exception as e:
        pass
